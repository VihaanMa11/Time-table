import { useState } from 'react';
import { TimeSlot } from '../types/timetable';
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"

interface TimeSlotFormProps {
  timeSlot?: TimeSlot;
  onSubmit: (timeSlot: Omit<TimeSlot, 'id'>) => void;
  onCancel: () => void;
}

export function TimeSlotForm({ timeSlot, onSubmit, onCancel }: TimeSlotFormProps) {
  const [formData, setFormData] = useState<Omit<TimeSlot, 'id'>>({
    day: timeSlot?.day || 'Monday',
    startTime: timeSlot?.startTime || '',
    endTime: timeSlot?.endTime || '',
    course: timeSlot?.course || '',
    faculty: timeSlot?.faculty || '',
    room: timeSlot?.room || '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{timeSlot ? 'Edit Time Slot' : 'Add Time Slot'}</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="day">Day</Label>
            <Select name="day" value={formData.day} onValueChange={(value) => setFormData(prev => ({ ...prev, day: value as TimeSlot['day'] }))}>
              <SelectTrigger>
                <SelectValue placeholder="Select a day" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Monday">Monday</SelectItem>
                <SelectItem value="Tuesday">Tuesday</SelectItem>
                <SelectItem value="Wednesday">Wednesday</SelectItem>
                <SelectItem value="Thursday">Thursday</SelectItem>
                <SelectItem value="Friday">Friday</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label htmlFor="startTime">Start Time</Label>
            <Input type="time" id="startTime" name="startTime" value={formData.startTime} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="endTime">End Time</Label>
            <Input type="time" id="endTime" name="endTime" value={formData.endTime} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="course">Course</Label>
            <Input type="text" id="course" name="course" value={formData.course} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="faculty">Faculty</Label>
            <Input type="text" id="faculty" name="faculty" value={formData.faculty} onChange={handleChange} required />
          </div>
          <div>
            <Label htmlFor="room">Room</Label>
            <Input type="text" id="room" name="room" value={formData.room} onChange={handleChange} required />
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onCancel}>Cancel</Button>
            <Button type="submit">{timeSlot ? 'Update' : 'Add'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

