'use client'

import { useState } from 'react';
import { Timetable, TimeSlot } from '../types/timetable';
import { TimetableSidebar } from './Sidebar';
import { TimetableView } from './TimetableView';
import { TimeSlotForm } from './TimeSlotForm';
import { mockTimetables } from '../data/mockTimetables';
import { SidebarProvider, SidebarInset } from "@/components/ui/sidebar"

export function TimetableManagement() {
  const [timetables, setTimetables] = useState<Timetable[]>(mockTimetables);
  const [selectedTimetableId, setSelectedTimetableId] = useState<string | null>(null);
  const [editingTimeSlot, setEditingTimeSlot] = useState<TimeSlot | null>(null);
  const [isAddingTimeSlot, setIsAddingTimeSlot] = useState(false);

  const selectedTimetable = timetables.find(t => t.id === selectedTimetableId) || null;

  const handleSelectTimetable = (id: string) => {
    setSelectedTimetableId(id);
  };

  const handleCreateTimetable = () => {
    // Implement timetable creation logic
    console.log('Create new timetable');
  };

  const handleAddTimeSlot = () => {
    setIsAddingTimeSlot(true);
  };

  const handleEditTimeSlot = (timeSlot: TimeSlot) => {
    setEditingTimeSlot(timeSlot);
  };

  const handleDeleteTimeSlot = (timeSlotId: string) => {
    if (selectedTimetable) {
      const updatedTimetable: Timetable = {
        ...selectedTimetable,
        timeSlots: selectedTimetable.timeSlots.filter(slot => slot.id !== timeSlotId)
      };
      setTimetables(timetables.map(t => t.id === updatedTimetable.id ? updatedTimetable : t));
    }
  };

  const handleTimeSlotSubmit = (timeSlotData: Omit<TimeSlot, 'id'>) => {
    if (selectedTimetable) {
      const updatedTimetable: Timetable = {
        ...selectedTimetable,
        timeSlots: editingTimeSlot
          ? selectedTimetable.timeSlots.map(slot =>
              slot.id === editingTimeSlot.id ? { ...timeSlotData, id: slot.id } : slot
            )
          : [...selectedTimetable.timeSlots, { ...timeSlotData, id: Date.now().toString() }]
      };
      setTimetables(timetables.map(t => t.id === updatedTimetable.id ? updatedTimetable : t));
      setEditingTimeSlot(null);
      setIsAddingTimeSlot(false);
    }
  };

  return (
    <SidebarProvider>
      <div className="flex h-screen">
        <TimetableSidebar
          timetables={timetables}
          selectedTimetable={selectedTimetableId}
          onSelectTimetable={handleSelectTimetable}
          onCreateTimetable={handleCreateTimetable}
        />
        <SidebarInset>
          <main className="flex-1 p-6 overflow-auto">
            <h1 className="text-3xl font-bold mb-6">Timetable Management</h1>
            {selectedTimetable ? (
              <TimetableView
                timetable={selectedTimetable}
                onEditTimeSlot={handleEditTimeSlot}
                onDeleteTimeSlot={handleDeleteTimeSlot}
                onAddTimeSlot={handleAddTimeSlot}
              />
            ) : (
              <p>Select a timetable from the sidebar or create a new one.</p>
            )}
            {(editingTimeSlot || isAddingTimeSlot) && (
              <TimeSlotForm
                timeSlot={editingTimeSlot || undefined}
                onSubmit={handleTimeSlotSubmit}
                onCancel={() => {
                  setEditingTimeSlot(null);
                  setIsAddingTimeSlot(false);
                }}
              />
            )}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}

