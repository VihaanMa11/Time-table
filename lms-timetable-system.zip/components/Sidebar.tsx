import { Timetable } from '../types/timetable';
import {
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { PlusCircle } from 'lucide-react'

interface SidebarProps {
  timetables: Timetable[];
  selectedTimetable: string | null;
  onSelectTimetable: (id: string) => void;
  onCreateTimetable: () => void;
}

export function TimetableSidebar({ timetables, selectedTimetable, onSelectTimetable, onCreateTimetable }: SidebarProps) {
  return (
    <Sidebar>
      <SidebarHeader>
        <h2 className="text-xl font-bold p-4">Timetables</h2>
      </SidebarHeader>
      <SidebarContent>
        <SidebarMenu>
          {timetables.map((timetable) => (
            <SidebarMenuItem key={timetable.id}>
              <SidebarMenuButton
                onClick={() => onSelectTimetable(timetable.id)}
                isActive={selectedTimetable === timetable.id}
              >
                {timetable.name}
              </SidebarMenuButton>
            </SidebarMenuItem>
          ))}
        </SidebarMenu>
      </SidebarContent>
      <div className="p-4">
        <Button onClick={onCreateTimetable} className="w-full">
          <PlusCircle className="mr-2 h-4 w-4" />
          Create Timetable
        </Button>
      </div>
    </Sidebar>
  )
}

