import { Timetable, TimeSlot } from '../types/timetable';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { PlusCircle, Edit, Trash } from 'lucide-react'

interface TimetableViewProps {
  timetable: Timetable;
  onEditTimeSlot: (timeSlot: TimeSlot) => void;
  onDeleteTimeSlot: (timeSlotId: string) => void;
  onAddTimeSlot: () => void;
}

export function TimetableView({ timetable, onEditTimeSlot, onDeleteTimeSlot, onAddTimeSlot }: TimetableViewProps) {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];
  const timeSlots = timetable.timeSlots.sort((a, b) => a.startTime.localeCompare(b.startTime));

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">{timetable.name}</h2>
        <Button onClick={onAddTimeSlot}>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Time Slot
        </Button>
      </div>
      <p>Semester: {timetable.semester} | Academic Year: {timetable.academicYear}</p>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Day</TableHead>
            <TableHead>Time</TableHead>
            <TableHead>Course</TableHead>
            <TableHead>Faculty</TableHead>
            <TableHead>Room</TableHead>
            <TableHead>Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {days.map(day => (
            timeSlots
              .filter(slot => slot.day === day)
              .map(slot => (
                <TableRow key={slot.id}>
                  <TableCell>{slot.day}</TableCell>
                  <TableCell>{slot.startTime} - {slot.endTime}</TableCell>
                  <TableCell>{slot.course}</TableCell>
                  <TableCell>{slot.faculty}</TableCell>
                  <TableCell>{slot.room}</TableCell>
                  <TableCell>
                    <Button variant="ghost" size="sm" onClick={() => onEditTimeSlot(slot)}>
                      <Edit className="h-4 w-4" />
                    </Button>
                    <Button variant="ghost" size="sm" onClick={() => onDeleteTimeSlot(slot.id)}>
                      <Trash className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

