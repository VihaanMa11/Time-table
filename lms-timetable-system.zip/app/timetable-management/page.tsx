import { TimetableManagement } from '../../components/TimetableManagement';

export default function TimetableManagementPage() {
  return (
    <div className="h-screen">
      <TimetableManagement />
    </div>
  );
}

