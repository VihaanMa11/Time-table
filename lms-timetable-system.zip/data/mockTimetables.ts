import { Timetable } from '../types/timetable';

export const mockTimetables: Timetable[] = [
  {
    id: '1',
    name: 'Computer Science - Year 1',
    semester: 'Fall 2023',
    academicYear: '2023-2024',
    timeSlots: [
      {
        id: '1',
        day: 'Monday',
        startTime: '09:00',
        endTime: '10:30',
        course: 'Introduction to Programming',
        faculty: 'Dr. Smith',
        room: 'CS101',
      },
      {
        id: '2',
        day: 'Tuesday',
        startTime: '11:00',
        endTime: '12:30',
        course: 'Discrete Mathematics',
        faculty: 'Prof. Johnson',
        room: 'Math201',
      },
      // Add more time slots as needed
    ],
  },
  {
    id: '2',
    name: 'Electrical Engineering - Year 2',
    semester: 'Spring 2024',
    academicYear: '2023-2024',
    timeSlots: [
      {
        id: '1',
        day: 'Wednesday',
        startTime: '14:00',
        endTime: '15:30',
        course: 'Circuit Analysis',
        faculty: 'Dr. Lee',
        room: 'EE202',
      },
      {
        id: '2',
        day: 'Thursday',
        startTime: '10:00',
        endTime: '11:30',
        course: 'Digital Systems Design',
        faculty: 'Prof. Garcia',
        room: 'EE205',
      },
      // Add more time slots as needed
    ],
  },
];

