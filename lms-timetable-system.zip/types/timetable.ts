export interface TimeSlot {
  id: string;
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday';
  startTime: string;
  endTime: string;
  course: string;
  faculty: string;
  room: string;
}

export interface Timetable {
  id: string;
  name: string;
  semester: string;
  academicYear: string;
  timeSlots: TimeSlot[];
}

